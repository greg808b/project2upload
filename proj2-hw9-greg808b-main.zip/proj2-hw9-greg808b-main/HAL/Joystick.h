/*
 * Joystick.h
 *
 *  Created on: Oct 28, 2021
 *      Author: Greg Brinson
 */

#ifndef HAL_JOYSTICK_H_
#define HAL_JOYSTICK_H_

#include <ti/devices/msp432p4xx/driverlib/driverlib.h>


struct _Joystick
{
    uint_fast16_t x;
    uint_fast16_t y;

    bool isTappedtoLeft;
};
typedef struct _Joystick Joystick;

/** Constructs a new Joystick object, given a valid port and pin. */
Joystick Joystick_construct();

/** Given a Joystick, determines if the joystick is pressed to left */
bool Joystick_isPressedtoLeft(Joystick* Joystick_p);

/** Given a Joystick, determines if the joystick is pressed to left */
bool Joystick_isPressedtoRight(Joystick* Joystick_p);

/** Given a Joystick, determines if it was "tapped" to left- it went from middle to left */
bool Joystick_isTappedtoLeft(Joystick* Joystick_p);

/** Given a Joystick, determines if it was "tapped" to left- it went from middle to left */
bool Joystick_isTappedtoRight(Joystick* Joystick_p);

/** Given a Joystick, determines if it was "tapped" to left- it went from middle to left */
bool Joystick_isTappedtoUp(Joystick* Joystick_p);

/** Given a Joystick, determines if it was "tapped" to left- it went from middle to left */
bool Joystick_isTappedtoDown(Joystick* Joystick_p);
int Joystick_val(Joystick* Joystick_p, int x);

/** Refreshes this Joystick so the Joystick FSM now has new outputs to interpret */
void Joystick_refresh(Joystick* Joystick);
void initADC();
void initJoyStick();
void startADC();

#endif /* HAL_JOYSTICK_H_ */
