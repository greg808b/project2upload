/**
 * Starter code for Project 2. Good luck!
 */
/*TODO TOTAL: add joystick functions for R U and D, following Left
 * fill out screens for settings
 *
 */

#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

/* HAL and Application includes */
#include <HAL/HAL.h>
#include <HAL/Timer.h>
#include <proj2_app.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
        // Stop Watchdog Timer - THIS SHOULD ALWAYS BE THE FIRST LINE OF YOUR MAIN
            WDT_A_holdTimer();

            // Initialize the system clock and background hardware timer, used to enable
            // software timers to time their measurements properly.
            InitSystemTiming();

            // Initialize the main Application object and the HAL.
            HAL hal = HAL_construct();
            App_proj2 app = App_proj2_construct(&hal);
            App_proj2_showTitleScreen(&hal.gfx);

            // Main super-loop! In a polling architecture, this function should call
            // your main FSM function over and over.
            while (true)
            {
                App_proj2_loop(&app, &hal);  //update my program, application state, output
                HAL_refresh(&hal); // check the inputs
            }
    }

App_proj2 App_proj2_construct(HAL* hal_p)
{
    // The App_proj2 object to initialize
    App_proj2 app;

//    // Initialization of FSM variables
    app.NumDebris = 0;
    int i; for(i=0;i<3;i++){
        app.highscore[i]=0;
    }
    app.first = 0;
    app.state = TITLE_SCREEN;
    app.timer = SWTimer_construct(TITLE_SCREEN_WAIT);
    //timer for game refresh (moving joystick and character)
    app.timer1 = SWTimer_construct(GAME_WAIT);
    //timer for debris construction
    app.debristimer = SWTimer_construct(DEBRIS_WAIT);
    app.debrismoveT = SWTimer_construct(DEBRIS_MOVEWAIT);
    app.shottimer = SWTimer_construct(SHOT_TIME);
    SWTimer_start(&app.timer);

    App_proj2_initGameVariables(&app, hal_p);


    // Return the completed Application struct to the user
    return app;
}

/**
 * The main super-loop function of the application. We place this inside of a
 * single infinite loop in main. In this way, we can model a polling system of
 * FSMs. Every cycle of this loop function, we poll each of the FSMs one time.
 */
void App_proj2_loop(App_proj2* app_p, HAL* hal_p)
{
    //check nonblocking code
    if (Button_isPressed(&hal_p->launchpadS1))
            LED_turnOn(&hal_p->launchpadLED1);
        else
            LED_turnOff(&hal_p->launchpadLED1);
//    if (Button_isTapped(&hal_p->boosterpackS2))
//                LED_toggle(&hal_p->boosterpackRed);
    //fsm for screens
    switch (app_p->state)
    {
        case TITLE_SCREEN:
            App_proj2_handleTitleScreen(app_p, hal_p);
            break;

        case INSTRUCTIONS_SCREEN:
            App_proj2_handleInstructionsScreen(app_p, hal_p);
            break;

        case GAME_SCREEN:
            App_proj2_handleGameScreen(app_p, hal_p);
            break;

        case RESULT_SCREEN:
            App_proj2_handleResultScreen(app_p, hal_p);
            break;
        case MENU_SCREEN:
            App_proj2_handleMenuScreen(hal_p, &hal_p->gfx, app_p);
            break;
        case GAMEOVER_SCREEN:
            App_proj2_handleGameOverScreen(app_p, hal_p);
            break;

        default:
            break;
    }
}

void App_proj2_initGameVariables(App_proj2* app_p, HAL* hal_p){
    //set default game variables
    app_p->cursor = CURSOR_1;
    // place character in middle bottom and lives 3
    app_p->x = 96;
    app_p->y = 125;
    app_p->lives = 3;
    app_p->score = 0;
    app_p->NumDebris = 0;
    //timer to create debris
    app_p->debristimer = SWTimer_construct(DEBRIS_WAIT);
    app_p->first++;
    //function for providing random number sequence rather than same sequence every time
    srand(time(NULL));
}

/*
 * Function that handles title screen
 * checks timer to see if title screen should be wiped and should move to the menu
 * starts timers for character movement refresh and debris creation
 */
void App_proj2_handleTitleScreen(App_proj2* app_p, HAL* hal_p)
{
    if (SWTimer_expired(&app_p->timer))
    {
        app_p->state = MENU_SCREEN;
        App_proj2_showMenuScreen(app_p, &hal_p->gfx);
        SWTimer_start(&app_p->timer1);


    }
}
void App_proj2_handleInstructionsScreen(App_proj2* app_p, HAL* hal_p){
    //change screen if joystick button clicked
    if (Button_isTapped(&hal_p->joystickb1))
        {
            // Update internal logical state
            app_p->state = MENU_SCREEN;
            App_proj2_showMenuScreen(app_p, &hal_p->gfx);
}
}


void App_proj2_handleGameScreen(App_proj2* app_p, HAL* hal_p){
//check if character timer expired then call update function to move character
        App_proj2_updateGameScreen(app_p,hal_p, &hal_p->gfx);
    if(app_p->lives<1){
        app_p->state = GAMEOVER_SCREEN;
        App_proj2_showGameOverScreen(app_p, &hal_p->gfx);
    }
}



void App_proj2_handleResultScreen(App_proj2* app_p, HAL* hal_p){
    //change screen if joystick button clicked
    if (Button_isTapped(&hal_p->joystickb1))
            {
                // Update internal logical state
                app_p->state = MENU_SCREEN;
                App_proj2_showMenuScreen(app_p, &hal_p->gfx);
    }
}

/*handles moving cursor up and down
 * and selecting screens based on cursor selection
 */
void App_proj2_handleMenuScreen(HAL* hal_p, GFX* gfx_p, App_proj2* app_p){
    //change screen if joystick button clicked
    if (Joystick_isTappedtoUp(&hal_p->joystick)) {
              app_p->cursor = (Cursor) (((int) app_p->cursor + 1) % NUM_TEST_OPTIONS);
              App_proj2_updateMenuScreen(app_p, &hal_p->gfx);
}
    if (Joystick_isTappedtoDown(&hal_p->joystick)) {
        if(app_p->cursor < 1){
            app_p->cursor = CURSOR_2;
        App_proj2_updateMenuScreen(app_p, &hal_p->gfx);
        }
        else{
                  app_p->cursor = (Cursor) (((int) app_p->cursor - 1) % NUM_TEST_OPTIONS);
                  App_proj2_updateMenuScreen(app_p, &hal_p->gfx);
        }
    }
    if (Button_isTapped(&hal_p->joystickb1))
        {
            switch (app_p->cursor)
            {
                // In the first three choices, we need to re-display the game screen
                // to reflect updated choices.
                // -----------------------------------------------------------------
                case CURSOR_0: // Game
                    App_proj2_initGameVariables(app_p,hal_p);
                    App_proj2_showGameScreen(app_p, &hal_p->gfx);
                    app_p->state = GAME_SCREEN;

                    break;

                case CURSOR_1: // How to
                    App_proj2_showInstructionsScreen(app_p, &hal_p->gfx);
                    app_p->state = INSTRUCTIONS_SCREEN;
                    break;

                case CURSOR_2: // High Score
                    App_proj2_showResultScreen(app_p, hal_p);
                    app_p->state = RESULT_SCREEN;
                    break;

            }
        }
}
//displays end game screen
void App_proj2_handleGameOverScreen(App_proj2* app_p, HAL* hal_p){
    if (Button_isTapped(&hal_p->joystickb1))
        {
            // Update internal logical state
            app_p->state = MENU_SCREEN;
            App_proj2_showMenuScreen(app_p, &hal_p->gfx);
}
}
/*
 * code to move cursor visibly on menu screen
 */
void App_proj2_updateMenuScreen(App_proj2* app_p, GFX* gfx_p){
        GFX_print(gfx_p, "  ", 7, 3);
        GFX_print(gfx_p, "  ", 9, 3);
        GFX_print(gfx_p, "  ", 11, 3);

        // Draw the cursor
        GFX_print(gfx_p, "o", 7 + (app_p->cursor)*2, 3);
}
/*
 * code to clear the current character position
 */
void clearChar(GFX* gfx_p, Graphics_Rectangle Clear){
    Graphics_setForegroundColor(&gfx_p->context, GRAPHICS_COLOR_BLACK);
    Graphics_fillRectangle(&gfx_p->context, &Clear);
    Graphics_setForegroundColor(&gfx_p->context, GRAPHICS_COLOR_WHITE);
}
/*
 * update game screen when joystick moved
 */
void App_proj2_updateGameScreen(App_proj2* app_p, HAL* hal_p, GFX* gfx_p){
    static Graphics_Rectangle R;
    static bool once = true;
    static bool first = true;
    static int count = 0;
    //new game conditions
if(app_p->first%2==0){
        R.xMin = 92; R.xMax = 98; R.yMin = 118; R.yMax = 124;
        SWTimer_start(&app_p->debristimer);
        app_p->first++;
        first = true;
        once=true;
        SWTimer_start(&app_p->timer1);
        SWTimer_start(&app_p->shottimer);
        count = 0;
        app_p->debrismoveT = SWTimer_construct(DEBRIS_MOVEWAIT);
    }
    if(SWTimer_expired(&app_p->debrismoveT)){
    updateDebris(app_p,hal_p,gfx_p, &first); }
    //if move time expired, check for movement again
if(SWTimer_expired(&app_p->timer1)){
        if(Joystick_isPressedtoRight(&hal_p->joystick)){
            if(app_p->x<121){
                app_p->x+=((Joystick_val(&hal_p->joystick, 0)-7000))/3000;
                clearChar(gfx_p, R);
                R.xMin=app_p->x-3; R.xMax = app_p->x+3;
                Graphics_fillRectangle(&gfx_p->context, &R);
            }
        }
        if(Joystick_isPressedtoLeft(&hal_p->joystick)){
            if(app_p->x>69){
                app_p->x-=(9000-(Joystick_val(&hal_p->joystick, 0)))/3000;
                clearChar(gfx_p, R);
                R.xMin=app_p->x-3; R.xMax = app_p->x+3;
                Graphics_fillRectangle(&gfx_p->context, &R);
            }
        }
        shootDebris(app_p,hal_p,gfx_p, R);
        SWTimer_start(&app_p->timer1);
}//make debris timer
        if(SWTimer_expired(&app_p->debristimer)){
            SWTimer_start(&app_p->debrismoveT);
            makeDebris(app_p, hal_p, gfx_p);
        }
            //make debris spawn faster
            if(app_p->score==1500&&once){
                once = false;
                app_p->debristimer = SWTimer_construct(DEBRIS_WAIT/2);
                SWTimer_start(&app_p->debristimer);
            }
            //make move faster each 1500 points
            if(app_p->score%1500==0&&app_p->score!=0&&(count<app_p->score/1500)){
                count++;
                app_p->debrismoveT = SWTimer_construct(DEBRIS_MOVEWAIT-(2*count));
                SWTimer_start(&app_p->debrismoveT);
            }

}
//function to shoot and update energy blasts
//i know its close to 60 but has long line to check for collision and brackets on separate lines and comments PLEASE
void shootDebris(App_proj2* app_p, HAL* hal_p, GFX* gfx_p, Graphics_Rectangle Char){
    static int shot = 0;
    static Graphics_Rectangle bullet[3];
    if(Button_isPressed(&hal_p->boosterpackS2)&&SWTimer_expired(&app_p->shottimer)){
        //if not 3 shots yet
    if(shot<3){
        bullet[shot].xMin = Char.xMin +2; bullet[shot].xMax = Char.xMax -2; bullet[shot].yMin = 114; bullet[shot].yMax = 116;
        shot++;
        SWTimer_start(&app_p->shottimer); }}
    //if there are bullets update them
    if(shot>0){
        int i;
        for(i=0;i<shot;i++){
            if(bullet[i].yMax < 5){
                clearChar(gfx_p,bullet[i]);
                if(shot==2&&i==0){
                    bullet[i]=bullet[i+1];}
                else if(shot==3&&i==0){
                    bullet[i]=bullet[i+1];
                    bullet[i+1]=bullet[i+2];}
                else if(shot==3&&i==1){
                    bullet[i]=bullet[i+1];}
            shot--;}}
                        int j;
        for(j = 0;j<shot; j++){
        clearChar(gfx_p,bullet[j]);
        bullet[j].yMin = bullet[j].yMin -2;
        bullet[j].yMax = bullet[j].yMax -2;
        Graphics_fillRectangle(&gfx_p->context, &bullet[j]);
        for(i=0;i<app_p->NumDebris;i++){
            //check for collision
        if((((bullet[j].yMin >=app_p->Debris[i].yMin)&&(bullet[j].yMin <= app_p->Debris[i].yMax))
            ||((bullet[j].yMax <=app_p->Debris[i].yMin)&&(bullet[j].yMax >= app_p->Debris[i].yMax)))
            &&(((bullet[j].xMin >=app_p->Debris[i].xMin)&&(bullet[j].xMin <= app_p->Debris[i].xMax))
            ||((bullet[j].xMax >=app_p->Debris[i].xMin)&&(bullet[j].xMax <= app_p->Debris[i].xMax)))){
            app_p->score = app_p->score +500;
            updateScore(app_p->score,gfx_p, 9 ,2);
            clearChar(gfx_p,app_p->Debris[i]);
            clearChar(gfx_p,bullet[j]);
            //update array so more bullets can be added
            if(shot==2&&i==0){
                                bullet[j]=bullet[j+1];}
                            else if(shot==3&&j==0){
                                bullet[j]=bullet[j+1];
                                bullet[j+1]=bullet[j+2]; }
                            else if(shot==3&&j==1){
                                bullet[j]=bullet[j+1]; }
            if(app_p->NumDebris>1)
                app_p->Debris[i] = app_p->Debris[i+1];
            if(app_p->NumDebris>2)
                app_p->Debris[i+1] = app_p->Debris[i+2];
            if(app_p->NumDebris>3)
                app_p->Debris[i+2] = app_p->Debris[i+3];
            app_p->NumDebris--;
            shot--;}}}}}
//display score value with 6 digits filled with 0's
void updateScore(int score, GFX* gfx_p, int x, int y){
    char newscore[50];
    sprintf(newscore, "%06d",score);
    GFX_print(gfx_p, newscore, x, y);
}
//move falling debris and check for collision with bottom and character
void updateDebris(App_proj2* app_p, HAL* hal_p, GFX* gfx_p, bool* first){
    int i;
    static Graphics_Rectangle life;
    if (*first==true){
    life.xMin= 38; life.xMax = 43;
    life.yMin = 105; life.yMax = 110;
    *first=false;
    }
    Graphics_Rectangle R;
    for(i=0;i<app_p->NumDebris;i++){
    R = app_p->Debris[i];
    clearChar(gfx_p, R);
    R.yMin = R.yMin +1;
    R.yMax = R.yMax +1;
    app_p->Debris[i] = R;
    Graphics_fillRectangle(&gfx_p->context, &R);
    //check for bottom
    if(R.yMax > 126){
        clearChar(gfx_p,app_p->Debris[i]);
        if(app_p->NumDebris>1)
            app_p->Debris[i] = app_p->Debris[i+1];
        if(app_p->NumDebris>2)
            app_p->Debris[i+1] = app_p->Debris[i+2];
        if(app_p->NumDebris>3)
            app_p->Debris[i+2] = app_p->Debris[i+3];
        app_p->NumDebris--;
        app_p->lives--;
        clearChar(gfx_p, life);
        life.xMin = life.xMin-9;
        life.xMax = life.xMax-9;
        }
    //check for character collision
    if(((((app_p->y-12)<app_p->Debris[i].yMax)
                &&(((app_p->x-3 <= app_p->Debris[i].xMin)&&(app_p->x+3 >= app_p->Debris[i].xMin))
                ||((app_p->x-3 <=app_p->Debris[i].xMax)&&(app_p->x+3 >= app_p->Debris[i].xMax)))))){
        clearChar(gfx_p,app_p->Debris[i]);
                if(app_p->NumDebris>1)
                    app_p->Debris[i] = app_p->Debris[i+1];
                if(app_p->NumDebris>2)
                    app_p->Debris[i+1] = app_p->Debris[i+2];
                if(app_p->NumDebris>3)
                    app_p->Debris[i+2] = app_p->Debris[i+3];
                app_p->NumDebris--;
                app_p->lives--;
                clearChar(gfx_p, life);
                life.xMin = life.xMin-9;
                life.xMax = life.xMax-9;
    }
    }

    SWTimer_start(&app_p->debrismoveT);}
//create debris
void makeDebris(App_proj2* app_p, HAL* hal_p, GFX* gfx_p){
    int r = rand()/(512)+63; // 0 to 64 then add 63. 63 to 127
                Graphics_Rectangle debrisR;
                debrisR.yMin = 0; debrisR.yMax = 10;
                //make in bounds
                if(r>121){
                    debrisR.xMin = 115; debrisR.xMax = 125;
                }
                else if(r<70){
                    debrisR.xMin = 70; debrisR.xMax = 80;
                }
                else {
                    debrisR.xMin = r-5; debrisR.xMax = r+5;
                }
                Graphics_fillRectangle(&gfx_p->context, &debrisR);
                app_p->Debris[app_p->NumDebris] = debrisR;
                app_p->NumDebris++;
                SWTimer_start(&app_p->debristimer);
}



/**
 * Sets up the proj2 game by initializing the game state to the Title
 * Screen state.
 */
void App_proj2_showTitleScreen(GFX* gfx_p)
{

    GFX_clear(gfx_p);


    GFX_print(gfx_p, "Space Invaders", 4, 5);
    GFX_print(gfx_p, "---------------------", 1, 0);
    GFX_print(gfx_p, "By: Greg Brinson", 6, 0);
}
/*
 * display instructions
 */
void App_proj2_showInstructionsScreen(App_proj2* app_p, GFX* gfx_p){
// Clear the screen from any old text state
    GFX_clear(gfx_p);

    // Display the text
    GFX_print(gfx_p, "HOW TO PLAY", 0, 6);
    GFX_print(gfx_p, "---------------------", 1, 0);
    GFX_print(gfx_p, "Defend earth!", 2, 0);
    GFX_print(gfx_p, "Shoot the falling", 3, 0);
    GFX_print(gfx_p, "asteroids earn points", 4, 0);
    GFX_print(gfx_p, "and save the day!", 5, 0);
    GFX_print(gfx_p, "Every asteroid that ", 6, 0);
    GFX_print(gfx_p, "hits the earth ", 7, 0);
    GFX_print(gfx_p, "costs you a life.", 8, 0);

    GFX_print(gfx_p, "Use JOYSTICK to move", 11, 0);
    GFX_print(gfx_p, "Press BB2 to shoot", 12, 0);
    GFX_print(gfx_p, "(Press JSB to return", 15, 0);
}
/*
 * display game initial state
 */
void App_proj2_showGameScreen(App_proj2* app_p, GFX* gfx_p){
    // Clear the screen from any old text state
    GFX_clear(gfx_p);

    // Display the text
    GFX_print(gfx_p, "ASTRO                ", 2, 2);
    GFX_print(gfx_p, "DEFENDERS", 3, 0);
    GFX_print(gfx_p, "SCORE               ", 8, 0);
    updateScore(app_p->score, gfx_p, 9, 2);
    GFX_print(gfx_p, "LIVES       ", 12, 0);
    Graphics_Rectangle R;
    R.xMax = 20;
    R.xMin = 25;
    R.yMax = 110;
    R.yMin = 105;
    Graphics_fillRectangle(&gfx_p->context, &R);
    R.xMin= 29; R.xMax = 34;
    Graphics_fillRectangle(&gfx_p->context, &R);
    R.xMin= 38; R.xMax = 43;
    Graphics_fillRectangle(&gfx_p->context, &R);
    Graphics_drawLineV(&gfx_p->context,63,0,127);
    Graphics_drawLineV(&gfx_p->context,127,0,127);
    R.xMin = 92; R.xMax = 98; R.yMin = 118; R.yMax = 124;
    Graphics_fillRectangle(&gfx_p->context, &R);
}
/*
 * display high scores. just 0 for now
 */
void App_proj2_showResultScreen(App_proj2* app_p, HAL* hal_p){
    // Print the splash text
    GFX_clear(&hal_p->gfx);
    GFX_print(&hal_p->gfx, "HIGH SCORES", 0, 6);
    GFX_print(&hal_p->gfx, "---------------------", 1, 0);

    int i;
    for(i=0;i<3;i++){
    updateScore(app_p->highscore[i], &hal_p->gfx,i*3+3, 8);
    }


}

/**
 *  show menu screen
 */
void App_proj2_showMenuScreen(App_proj2* app_p, GFX* gfx_p){
    // Clear the screen from any old text state
    GFX_clear(gfx_p);

    // Display the text
    GFX_print(gfx_p, "     MAIN MENU", 4, 0);
    GFX_print(gfx_p, "---------------------", 1, 0);
    GFX_print(gfx_p, "Play Game", 7, 5);  /////// 5 spaces
    GFX_print(gfx_p, "     How to Play", 9, 0);
    GFX_print(gfx_p, "     High Scores", 11, 0);

    GFX_print(gfx_p, "o", 7 + (app_p->cursor)*2, 3);
}
void App_proj2_showGameOverScreen(App_proj2* app_p, GFX* gfx_p){
    // Clear the screen from any old text state
    GFX_clear(gfx_p);
    app_p->cursor = CURSOR_0;

    // Display the text
    GFX_print(gfx_p, "GAME OVER", 4, 6);
    updateScore(app_p->score,gfx_p, 7, 8);
    if(app_p->score>=app_p->highscore[2]){
        app_p->highscore[2] = app_p->score;
    }
    if(app_p->score>=app_p->highscore[1]){
        app_p->highscore[2] = app_p->highscore[1];
        app_p->highscore[1] = app_p->score;
    }
    if(app_p->score>=app_p->highscore[0]){
        app_p->highscore[1] = app_p->highscore[0];
        app_p->highscore[0] = app_p->score;
    }

}


