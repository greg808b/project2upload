/**
 * Constructs a Joystick
 * Initializes the output FSMs.
 *

 *
 * @return a constructed Joystick with debouncing and output FSMs initialized
 */

#include <HAL/Joystick.h>

#define LEFT_THRESHOLD 6000
#define RIGHT_THRESHOLD 10000
#define UP_THRESHOLD 6000
#define DOWN_THRESHOLD 10000

enum _JoystickDebounceStateLeft { LEFT, NOT_LEFT };
typedef enum _JoystickDebounceStateLeft JoystickDebounceStateLeft;
enum _JoystickDebounceStateRight { RIGHT, NOT_RIGHT };
typedef enum _JoystickDebounceStateRight JoystickDebounceStateRight;
enum _JoystickDebounceStateUp { UP, NOT_UP };
typedef enum _JoystickDebounceStateUp JoystickDebounceStateUp;
enum _JoystickDebounceStateDown { DOWN, NOT_DOWN };
typedef enum _JoystickDebounceStateDown JoystickDebounceStateDown;


Joystick Joystick_construct()
{
    // The Joystick object which will be returned at the end of construction
    Joystick Joystick;

    initADC();
    initJoyStick();
    startADC();



    // Initialize all buffered outputs of the Joystick
//    Joystick.pushState = RELEASED;
//    Joystick.isTapped = false;

    // Return the constructed Joystick object to the user
    return Joystick;
}

void initADC() {
    ADC14_enableModule();

    ADC14_initModule(ADC_CLOCKSOURCE_SYSOSC,
                     ADC_PREDIVIDER_1,
                     ADC_DIVIDER_1,
                     ADC_NOROUTE
                     );

    // This configures the ADC to store output results
    // in ADC_MEM0 for joystick X.
    // Todo: if we want to add joystick Y, then, we have to use more memory locations
    ADC14_configureMultiSequenceMode(ADC_MEM0, ADC_MEM1, true);

    // This configures the ADC in manual conversion mode
    // Software will start each conversion.
    ADC14_enableSampleTimer(ADC_AUTOMATIC_ITERATION);
}


void startADC() {
   // Starts the ADC with the first conversion
   // in repeat-mode, subsequent conversions run automatically
   ADC14_enableConversion();
   ADC14_toggleConversionTrigger();
}


// Interfacing the Joystick with ADC (making the proper connections in software)
void initJoyStick() {

    // This configures ADC_MEM0 to store the result from
    // input channel A15 (Joystick X), in non-differential input mode
    // (non-differential means: only a single input pin)
    // The reference for Vref- and Vref+ are VSS and VCC respectively
    ADC14_configureConversionMemory(ADC_MEM0,
                                  ADC_VREFPOS_AVCC_VREFNEG_VSS,
                                  ADC_INPUT_A15,                 // joystick X
                                  ADC_NONDIFFERENTIAL_INPUTS);

    // This selects the GPIO as analog input
    // A15 is multiplexed on GPIO port P6 pin PIN0

    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P6,
                                               GPIO_PIN0,
                                               GPIO_TERTIARY_MODULE_FUNCTION);

    ADC14_configureConversionMemory(ADC_MEM1,
                                      ADC_VREFPOS_AVCC_VREFNEG_VSS,
                                      ADC_INPUT_A9,                 // joystick y
                                      ADC_NONDIFFERENTIAL_INPUTS);
    // This selects the GPIO as analog input
        // A15 is multiplexed on GPIO port P4 pin PIN4
        GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4,
                                                   GPIO_PIN4,
                                                   GPIO_TERTIARY_MODULE_FUNCTION);
}

/*
 * refreshes the input of the provided joystick by polling its x and y
 */
void Joystick_refresh(Joystick* joystick_p)
{
    joystick_p->x = ADC14_getResult(ADC_MEM0);
    joystick_p->y = ADC14_getResult(ADC_MEM1);
}



/** Given a Joystick, determines if the joystick is pressed to left */
bool Joystick_isPressedtoLeft(Joystick* joystick_p){
//    if(hal_p->joystick.x<3000)
//        return true;
//    else
//        return false;
    return (joystick_p->x < LEFT_THRESHOLD);
}
bool Joystick_isPressedtoRight(Joystick* joystick_p){
//    if(hal_p->joystick.x<3000)
//        return true;
//    else
//        return false;
    return (joystick_p->x > RIGHT_THRESHOLD);
}

/** Given a Joystick, determines if it was "tapped" to left- it went from middle to left */
bool Joystick_isTappedtoLeft(Joystick* joystick_p){
    static JoystickDebounceStateLeft state = NOT_LEFT;
    bool output=false;

    switch(state){
    case NOT_LEFT:
        if(joystick_p->x < LEFT_THRESHOLD){
            state = LEFT;
            output = true;
            }
        break;
    case LEFT:
        if(joystick_p->x > LEFT_THRESHOLD){
            state = NOT_LEFT;
                    }
    }
    return output;
}
bool Joystick_isTappedtoRight(Joystick* joystick_p){
    static JoystickDebounceStateRight state = NOT_RIGHT;
    bool output=false;

    switch(state){
    case NOT_RIGHT:
        if(joystick_p->x < RIGHT_THRESHOLD){
            state = RIGHT;
            output = true;
            }
        break;
    case RIGHT:
        if(joystick_p->x > RIGHT_THRESHOLD){
            state = NOT_RIGHT;
                    }
    }
    return output;
}
bool Joystick_isTappedtoUp(Joystick* joystick_p){
    static JoystickDebounceStateUp state = NOT_UP;
    bool output=false;

    switch(state){
    case NOT_UP:
        if(joystick_p->y < UP_THRESHOLD){
            state = UP;
            output = true;
            }
        break;
    case UP:
        if(joystick_p->y > UP_THRESHOLD){
            state = NOT_UP;
                    }
    }
    return output;
}
bool Joystick_isTappedtoDown(Joystick* joystick_p){
    static JoystickDebounceStateDown state = NOT_DOWN;
    bool output=false;

    switch(state){
    case NOT_DOWN:
        if(joystick_p->y < DOWN_THRESHOLD){
            state = DOWN;
            output = true;
            }
        break;
    case DOWN:
        if(joystick_p->y > DOWN_THRESHOLD){
            state = NOT_DOWN;
                    }
    }
    return output;
}
int Joystick_val(Joystick* joystick_p, int x){
    switch(x){
    case 0:
        return joystick_p->x;
    case 1:
            return joystick_p->y;
        }
}







